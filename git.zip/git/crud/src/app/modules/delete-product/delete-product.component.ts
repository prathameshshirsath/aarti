import { ProductService } from 'src/app/services/product.service';
import { BsModalRef } from 'ngx-bootstrap/modal';
import { ToastrService } from 'ngx-toastr';
import { FormControl, FormGroup } from '@angular/forms';
import { Component, Input, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-delete-product',
  templateUrl: './delete-product.component.html',
  styleUrls: ['./delete-product.component.scss']
})
export class DeleteProductComponent {
  @Input() product: any;
  @Output() close = new EventEmitter();

  public productForm = new FormGroup({
    name: new FormControl(""),
    description: new FormControl(""),
    price: new FormControl(""),
  });

  constructor(
    private productService: ProductService,
    private toastrService: ToastrService,
    public bsModalRef: BsModalRef
  ) { }

  ngOnInit() {
    if (this.product) {
      this.productForm.patchValue(this.product);
    }
  }

  public onClose(): void {
    this.close.emit();
    this.bsModalRef.hide(); 
  }

  // public yes(): void {
  //   this.confirmDelete();
  // }

  // private confirmDelete(): void {
  //   const confirmed = confirm("Are you sure you want to delete this product?");
  //   if (confirmed) {
  //     this.performDelete();
  //   }
  // }

  public performDelete(): void {
    let payload = this.assignValueToModel();
    this.productService.deleteProduct(payload).subscribe((response: any) => {
      this.toastrService.success("product deleted successfully", "success");
      this.onClose();
    }, (error: any) => {
      this.toastrService.error("Error deleting teacher", "Error")
    }
    );
  }

  private assignValueToModel(): any {
    let product = {
      "id": this.product ? this.product.id : 0,
      "name": this.productForm.get("name")?.value,
      "description": this.productForm.get("description")?.value,
      "price": this.productForm.get("price")?.value
    }
    return product;
  }
}

