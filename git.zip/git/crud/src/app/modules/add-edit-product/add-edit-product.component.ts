import { Component, Input, Output, EventEmitter } from '@angular/core';
import { ProductService } from 'src/app/services/product.service';
import { FormControl, FormGroup } from '@angular/forms';
import { ToastrService } from 'ngx-toastr';
import { Validators } from '@angular/forms';
@Component({
  selector: 'app-add-edit-product',
  templateUrl: './add-edit-product.component.html',
  styleUrls: ['./add-edit-product.component.scss']
})
export class AddEditProductComponent {
  @Input() product: any;
  @Output() close = new EventEmitter();

  public productForm = new FormGroup(
    {
      acceptTerms: new FormControl(""),
      firstName: new FormControl("", [Validators.required, Validators.maxLength(10), Validators.minLength(3)]),
      lastName: new FormControl("", [Validators.required, Validators.maxLength(10), Validators.minLength(3)]),
      email: new FormControl("", [Validators.required, Validators.pattern(/^[\w-]+(\.[\w-]+)*@([\w-]+\.)+[a-zA-Z]{2,7}$/)]),
      city: new FormControl("", [Validators.required]),
      gender: new FormControl("", [Validators.required]),
      class: new FormControl("", [Validators.required]),
      phone: new FormControl("", [Validators.required, Validators.pattern("^((\\+91-?)|0)?[0-9]{10}$")]),
    }
  )
  constructor(private productService: ProductService,
    private toastrService: ToastrService
  ) { }

  ngOnInit() {
    if (this.product) {
      this.productForm.patchValue(this.product);
    }
  }

  public onClose(): void {
    this.close.emit();
  }

  public save(): void {
    let payload = this.assignValueToModel();
    if (!this.product) {
      this.addProduct(payload);
    } else {
      this.updateProduct(payload);
    }
  }

  private addProduct(payload: any): void {
    this.productService.addProduct(payload).subscribe((response: any) => {
      this.toastrService.success("Teacher added successfully", "success");
      this.onClose();
    }, (error: any) => {
      this.toastrService.error("Error adding teacher", "Error")
    }
    );
  }
  private updateProduct(payload: any): void {
    this.productService.updateProduct(payload).subscribe((response: any) => {
      this.toastrService.success("Teacher updated successfully", "success");
      this.onClose();
    }, (error: any) => {
      this.toastrService.error("Error updating product", "Error")
    });
  }
  public checkIfControlValid(controlName: string): any {
    return this.productForm.get(controlName)?.invalid &&
      this.productForm.get(controlName)?.errors &&
      (this.productForm.get(controlName)?.dirty || this.productForm.get(controlName)?.touched);

  }
  public checkControlHasError(controlName: string, error: string): any {
    return this.productForm.get(controlName)?.hasError(error);
  }

  private assignValueToModel(): any {
    let product = {
      "id": this.product ? this.product.id : 0,
      "firstName": this.productForm.get("firstName")?.value,
      "lastName": this.productForm.get("lastName")?.value,
      "email": this.productForm.get("email")?.value,
      "phone": this.productForm.get("phone")?.value,
      "gender": this.productForm.get("gender")?.value,
      "city": this.productForm.get("city")?.value,
      "acceptTerms": this.productForm.get("acceptTerms")?.value,
    }
    return product;
  }
}
