import { Component, OnInit } from '@angular/core';
import { ProductService } from 'src/app/services/product.service'
import { BsModalRef, BsModalService } from 'ngx-bootstrap/modal'
import { AddEditProductComponent } from '../add-edit-product/add-edit-product.component';
import { DeleteProductComponent } from '../delete-product/delete-product.component'

import { ToastrService } from 'ngx-toastr';
@Component({
  selector: 'app-product-list',
  templateUrl: './product-list.component.html',
  styleUrls: ['./product-list.component.scss']
})

export class ProductListComponent implements OnInit {
  public totalCount: number = 0;
  public products: any[] = [];
  public addEditProductModal!: BsModalRef;
  public deleteProductModal!: BsModalRef;

  constructor(
    private productService: ProductService,
    private toastrService: ToastrService,
    private modalService: BsModalService
  ) { }

  ngOnInit() {
    this.loadTeachers();
  }

  loadTeachers(): void {
    this.productService.getProducts().subscribe((response: any) => {
      this.products = response;
      this.totalCount = this.products.length;
    }, (error: any) => {
      this.toastrService.error("Error loading products list", "Error");
    }
    )
  }

  public openAddEditProductsModal(products: any = null): void {
    this.addEditProductModal = this.modalService.show(AddEditProductComponent, {
      initialState: { product: products }, class: "modal-lg",
      ignoreBackdropClick: true
    });
    this.addEditProductModal.content.close.subscribe(() => {
      this.addEditProductModal.hide();
      this.loadTeachers();
    })
  }

  public openDeleteProductsModal(products: any = null): void {
    this.deleteProductModal = this.modalService.show(DeleteProductComponent, {
      initialState: { product: products }, class: "modal-lg",
      ignoreBackdropClick: true
    });
    this.deleteProductModal.content.close.subscribe(() => {
      this.deleteProductModal.hide();
      this.loadTeachers();
    })
  }

  // public checkIfControlValid(controlName: string): boolean {
  //   return 
  // }



}  