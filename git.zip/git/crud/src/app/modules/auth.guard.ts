// import { Injectable } from '@angular/core';
// import { Router } from '@angular/router';
// import { AuthService } from './auth.service';


// @Injectable(
//   {
//     providedIn: 'root'
//   }
// )

// export class AuthGuard {
//   constructor(
//     private authService: AuthService,
//     Private router: Router) {

//   }



//   canActivate() {
//     let isUserLoggedIn = localStorage.getItem("userName") !== null;
//     if (isUserLoggedIn) {
//       return true;
//     }
//     else {
//       this.router.navigate(['/login'])
//       return false;
//     }
//   }
// }


import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from './auth.service'; // Import your AuthService

@Injectable({
  providedIn: 'root',
})
export class AuthGuard {
  constructor(private authService: AuthService, private router: Router) { }


  canActivate() {
    let isUserLoggedIn = localStorage.getItem("userName") !== null;
    if (isUserLoggedIn) {
      return true;
    }
    else {
      this.router.navigate(['/login'])
      return false;
    }
  }
}


