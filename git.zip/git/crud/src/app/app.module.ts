import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { Route, Routes, RouterModule } from '@angular/router';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { NavbarComponent } from './modules/navbar/navbar.component';
import { FooterComponent } from './modules/footer/footer.component';
import { SidebarComponent } from './modules/sidebar/sidebar.component';
import { HomeComponent } from './modules/home/home.component';
import { ProductListComponent } from './modules/product-list/product-list.component';
import { FormsModule } from '@angular/forms';
import { ProductService } from './services/product.service'
import { NgxDatatableModule } from '@swimlane/ngx-datatable';
import { AddEditProductComponent } from './modules/add-edit-product/add-edit-product.component';
import { ToastrModule } from 'ngx-toastr';
import { HttpClientModule } from '@angular/common/http';
import { ModalModule } from 'ngx-bootstrap/modal';
import { ReactiveFormsModule } from '@angular/forms';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { DeleteProductComponent } from './modules/delete-product/delete-product.component';
import { LoginComponent } from './modules/login/login.component';
const appRoutes: Routes = [
  { path: 'product-list', component: ProductListComponent }
]
@NgModule({
  declarations: [
    AppComponent,
    NavbarComponent,
    FooterComponent,
    SidebarComponent,
    HomeComponent,
    ProductListComponent,
    AddEditProductComponent,
    DeleteProductComponent,
    LoginComponent,
  ],

  imports: [
    RouterModule.forRoot(appRoutes),
    BrowserModule,
    HttpClientModule,
    BrowserAnimationsModule,
    AppRoutingModule,
    AppRoutingModule,
    FormsModule,
    ToastrModule.forRoot(),
    ModalModule.forRoot(),
    NgxDatatableModule,
    ReactiveFormsModule
  ],

  providers: [ProductService],
  bootstrap: [HomeComponent]
  
})
export class AppModule { }
