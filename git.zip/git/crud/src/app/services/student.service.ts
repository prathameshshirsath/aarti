import { Injectable } from '@angular/core';
import { from, Observable } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { HttpClient } from '@angular/common/http'

@Injectable({
  providedIn: 'root'
})
export class StudentService {

  constructor(private httpClient: HttpClient) { }

  public getProducts(): any {
    return this.httpClient.get(`http://localhost:3000/students`)
  }

  public addProduct(product: any): any {
    return this.httpClient.post(`http://localhost:3000/students`, product)
  }
  public updateProduct(product: any): any {
    return this.httpClient.put(`http://localhost:3000/students/${product.id}`, product)
  }
  public deleteProduct(product: any): any {
    return this.httpClient.delete(`http://localhost:3000/students/${product.id}`, product)
  }
}




